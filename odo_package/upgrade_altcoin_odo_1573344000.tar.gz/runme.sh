#set -x
file=/tmp/$$
#echo "runme.sh exe"

if [ -e /dev/mtd8 ]; then
    if [ -e initramfs.bin.SD ]; then
        #echo "flash romfs"
        flash_eraseall /dev/mtd8 >/dev/null 2>&1
        nandwrite -p /dev/mtd8 initramfs.bin.SD >/dev/null 2>&1
    fi

    if [ -e am335x-boneblack-blackmainer.dtb ]; then
        flash_eraseall /dev/mtd6 >/dev/null 2>&1
        nandwrite -p /dev/mtd6 am335x-boneblack-blackmainer.dtb >/dev/null 2>&1
    fi

    if [ -e uImage.bin ]; then
        #echo "flash kernel"
        flash_eraseall /dev/mtd7 >/dev/null 2>&1
        nandwrite -p /dev/mtd7 uImage.bin >/dev/null 2>&1
    fi
    if [ -e u-boot.img ]; then
        #echo "flash kernel"
        flash_eraseall /dev/mtd4 >/dev/null 2>&1
        nandwrite -p /dev/mtd4 u-boot.img >/dev/null 2>&1
        flash_eraseall /dev/mtd5 >/dev/null 2>&1
    fi
fi

if [ -e /dev/mtd10 ]; then
    if [ -e fpgabitlist ]; then
		for ct_string in `cat fpgabitlist`
		do
			coin_type=`echo $ct_string | awk '{split($0 ,a,"[\"]");print a[2]}'`
			if [ "${coin_type}" == "keccakc" ]||[ "${coin_type}" == "keccakd" ];then
				cp -rf cgminer_$coin_type.conf /fpgabit/
			else
				cp -rf cgminer_$coin_type.conf /fpgabit/
				cp -rf fpgaminer_top_$coin_type.bit /fpgabit/
			fi
			
		done
		
    fi
fi

